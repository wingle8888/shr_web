﻿STM32H750 Development Board - Technical Package
STM32H750 开发板技术资料包

Contents / 内容:
- pinout.txt  Pin definitions / 引脚定义
- specs.txt   Specifications / 规格参数
- quickstart.txt  Quick start / 快速入门

SHR Dev Board Mall
