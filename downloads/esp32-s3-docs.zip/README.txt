﻿ESP32-S3 DevKit Technical Package
ESP32-S3 开发套件技术资料

- pinout.txt
- specs.txt
- quickstart.txt
